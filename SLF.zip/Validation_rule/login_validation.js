module.exports={
	login: {
		username: {required: true,message: 'Username field Required.'},
		password: {required: true,message: 'Password field Required'}
	}
}